using Microsoft.Playwright;
using Microsoft.Playwright.NUnit;
using NUnit.Framework;
using Npgsql;
using System.Net.Http;
using System.Text.Json;
using EcommerceTests.Helpers;
using EcommerceTests.PageObjects;
using System;
using System.Threading.Tasks;

namespace EcommerceTests.Integration
{
    [TestFixture]
    public class PromotionFlowTests : PageTest
    {
        private ApiClient _apiClient;
        private DatabaseHelper _dbHelper;
        private CheckoutPage _checkoutPage;

        [SetUp]
        public async Task Setup()
        {
            _apiClient = new ApiClient("http://localhost:3000");
            await _apiClient.ResetAsync();

            _dbHelper = new DatabaseHelper("localhost", 5432, "testshop", "testuser", "testpass");
            _dbHelper.Connect();

            _checkoutPage = new CheckoutPage(Page);
            await _checkoutPage.NavigateAsync();
        }

        [TearDown]
        public async Task Cleanup()
        {
            if (_apiClient != null)
            {
                await _apiClient.ResetAsync();
            }
            if (_dbHelper != null)
            {
                _dbHelper.Disconnect();
            }
        }

        [Test]
        public async Task TestFullPromotionFlowHappyPath()
        {
            // 1. Create Promotion via API
            var promoData = new
            {
                code = "SPRING25",
                discountType = "PERCENTAGE",
                discountValue = 25,
                category = "ELECTRONICS",
                maxUses = 100,
                validFrom = DateTime.UtcNow.ToString("O"),
                validUntil = DateTime.UtcNow.AddDays(10).ToString("O")
            };
            var promo = await _apiClient.CreatePromotionAsync(promoData);
            Assert.IsNotNull(promo.PromotionId);

            // 2. UI actions
            await _checkoutPage.ApplyPromoCodeAsync("SPRING25");
            await _checkoutPage.VerifyDiscountApplied(250.00m);
            
            var originalPrice = await _checkoutPage.GetOriginalPriceAsync();
            Assert.AreEqual(1000.00m, originalPrice);

            var finalPrice = await _checkoutPage.GetFinalPriceAsync();
            Assert.AreEqual(750.00m, finalPrice);

            var orderId = await _checkoutPage.PlaceOrderAsync();
            Assert.IsNotEmpty(orderId);

            // 3. Verify Database
            var order = _dbHelper.GetOrderById(orderId);
            Assert.IsNotNull(order);
            Assert.AreEqual("SPRING25", order.PromotionCode);
            Assert.AreEqual(1000.00m, order.OriginalAmount);
            Assert.AreEqual(250.00m, order.DiscountAmount);
            Assert.AreEqual(750.00m, order.FinalAmount);

            var audit = _dbHelper.GetAuditLogByOrderId(orderId);
            Assert.IsNotNull(audit);
            Assert.AreEqual(promo.PromotionId, audit.PromotionId);
            Assert.AreEqual(250.00m, audit.DiscountApplied);
        }

        [Test]
        public async Task TestInvalidPromoCode()
        {
            await _checkoutPage.ApplyPromoCodeAsync("INVALID123");
            
            bool isErrorDisplayed = await _checkoutPage.IsErrorDisplayedAsync();
            Assert.IsTrue(isErrorDisplayed);
            
            string errorMsg = await _checkoutPage.GetErrorMessageAsync();
            Assert.IsTrue(errorMsg.Contains("Invalid") || errorMsg.Contains("not found"), $"Actual error message: {errorMsg}");
            
            var discount = await _checkoutPage.GetDiscountAmountAsync();
            Assert.AreEqual(0m, discount);
        }

        [Test]
        public async Task TestExpiredPromoCode()
        {
            var promoData = new
            {
                code = "EXPIRED50",
                discountType = "PERCENTAGE",
                discountValue = 50,
                category = "ELECTRONICS",
                maxUses = 100,
                validFrom = DateTime.UtcNow.AddDays(-10).ToString("O"),
                validUntil = DateTime.UtcNow.AddDays(-1).ToString("O")
            };
            await _apiClient.CreatePromotionAsync(promoData);

            await _checkoutPage.ApplyPromoCodeAsync("EXPIRED50");
            
            bool isErrorDisplayed = await _checkoutPage.IsErrorDisplayedAsync();
            Assert.IsTrue(isErrorDisplayed);
            
            string errorMsg = await _checkoutPage.GetErrorMessageAsync();
            Assert.IsTrue(errorMsg.Contains("expired") || errorMsg.Contains("Invalid"), $"Actual error message: {errorMsg}");
        }

        [Test]
        public async Task TestWrongCategoryPromo()
        {
            var promoData = new
            {
                code = "BOOK50",
                discountType = "PERCENTAGE",
                discountValue = 50,
                category = "BOOKS",
                maxUses = 100,
                validFrom = DateTime.UtcNow.ToString("O"),
                validUntil = DateTime.UtcNow.AddDays(10).ToString("O")
            };
            await _apiClient.CreatePromotionAsync(promoData);

            await _checkoutPage.ApplyPromoCodeAsync("BOOK50");
            
            bool isErrorDisplayed = await _checkoutPage.IsErrorDisplayedAsync();
            Assert.IsTrue(isErrorDisplayed);
            
            string errorMsg = await _checkoutPage.GetErrorMessageAsync();
            Assert.IsTrue(errorMsg.Contains("category") || errorMsg.Contains("not applicable") || errorMsg.Contains("Invalid"), $"Actual error message: {errorMsg}");
        }
    }
}
