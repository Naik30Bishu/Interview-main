using Microsoft.Playwright;
using System.Threading.Tasks;
using System;

namespace EcommerceTests.PageObjects
{
    public class CheckoutPage
    {
        private readonly IPage _page;

        private ILocator PromoCodeInput => _page.Locator("#promo-code");
        private ILocator ApplyPromoButton => _page.Locator("#apply-promo");
        private ILocator OriginalPrice => _page.Locator(".original-price");
        private ILocator DiscountAmount => _page.Locator(".discount-amount");
        private ILocator FinalPrice => _page.Locator(".final-price");
        private ILocator PlaceOrderButton => _page.Locator("#place-order");
        private ILocator OrderNumber => _page.Locator(".order-number");
        private ILocator SuccessMessage => _page.Locator(".success-message");
        private ILocator ErrorMessage => _page.Locator(".error-message");

        public CheckoutPage(IPage page)
        {
            _page = page;
        }

        public async Task NavigateAsync()
        {
            await _page.GotoAsync("http://localhost:8080");
        }

        public async Task ApplyPromoCodeAsync(string code)
        {
            await PromoCodeInput.FillAsync(code);
            await ApplyPromoButton.ClickAsync();
        }

        private async Task<decimal> ParsePriceAsync(ILocator locator)
        {
            var text = await locator.TextContentAsync();
            if (string.IsNullOrWhiteSpace(text)) return 0;
            return decimal.Parse(text.Replace("$", "").Replace(",", "").Replace("-", "").Trim());
        }

        public async Task<decimal> GetOriginalPriceAsync()
        {
            return await ParsePriceAsync(OriginalPrice);
        }

        public async Task<decimal> GetDiscountAmountAsync()
        {
            return await ParsePriceAsync(DiscountAmount);
        }

        public async Task<decimal> GetFinalPriceAsync()
        {
            return await ParsePriceAsync(FinalPrice);
        }

        public async Task VerifyDiscountApplied(decimal expectedDiscount)
        {
            await DiscountAmount.WaitForAsync(new LocatorWaitForOptions { State = WaitForSelectorState.Visible, Timeout = 10000 });
            var discount = await GetDiscountAmountAsync();
            if (discount != expectedDiscount)
            {
                throw new Exception($"Expected discount {expectedDiscount} but got {discount}");
            }
        }

        public async Task<string> PlaceOrderAsync()
        {
            await PlaceOrderButton.ClickAsync();
            await OrderNumber.WaitForAsync(new LocatorWaitForOptions { State = WaitForSelectorState.Visible, Timeout = 10000 });
            var orderNumText = await OrderNumber.TextContentAsync();
            return orderNumText.Replace("Order #", "").Trim();
        }

        public async Task<bool> IsErrorDisplayedAsync()
        {
            try
            {
                await ErrorMessage.WaitForAsync(new LocatorWaitForOptions { State = WaitForSelectorState.Visible, Timeout = 5000 });
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<string> GetErrorMessageAsync()
        {
            return await ErrorMessage.TextContentAsync();
        }
    }
}
