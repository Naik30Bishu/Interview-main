using Microsoft.Playwright;
using Microsoft.Playwright.NUnit;
using NUnit.Framework;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace EcommerceTests
{
    [TestFixture]
    public class LoginTests : PageTest
    {
        private string baseUrl = "https://example-shop.com";
        private string email = "test@example.com";
        private string password = "Password123!";

        [SetUp]
        public async Task Setup()
        {
            await Page.GotoAsync($"{baseUrl}/login");
        }

        private async Task DoLogin(string userEmail, string userPassword)
        {
            await Page.Locator("#email").FillAsync(userEmail);
            await Page.Locator("#password").FillAsync(userPassword);
            await Page.Locator("button[type='submit']").ClickAsync();
        }

        [Test]
        public async Task UserCanLoginWithValidCredentials()
        {
            await DoLogin(email, password);

            await Expect(Page).ToHaveURLAsync($"{baseUrl}/dashboard");
            await Expect(Page.Locator(".user-name")).ToHaveTextAsync("Test User");
        }

        [Test]
        public async Task LoginFailsWithInvalidPassword()
        {
            await DoLogin(email, "wrongpassword");

            await Expect(Page.Locator(".error-message")).ToContainTextAsync("Invalid");
        }

        [Test]
        public async Task LoginFailsWithEmptyFields()
        {
            await Page.Locator("button[type='submit']").ClickAsync();

            await Expect(Page.Locator("#email-error")).ToBeVisibleAsync();
            await Expect(Page.Locator("#password-error")).ToBeVisibleAsync();
        }

        [Test]
        public async Task RememberMeCheckboxWorks()
        {
            await Page.Locator("#email").FillAsync(email);
            await Page.Locator("#password").FillAsync(password);
            await Page.Locator("#remember-me").CheckAsync();
            await Page.Locator("button[type='submit']").ClickAsync();

            await Expect(Page).ToHaveURLAsync($"{baseUrl}/dashboard");

            // Verify session persistence in a new page within the same context
            var newPage = await Page.Context.NewPageAsync();
            await newPage.GotoAsync($"{baseUrl}/dashboard");

            await Expect(newPage).ToHaveURLAsync($"{baseUrl}/dashboard");
            await newPage.CloseAsync();
        }

        [Test]
        public async Task UserCanLogout()
        {
            await DoLogin(email, password);
            await Expect(Page).ToHaveURLAsync($"{baseUrl}/dashboard");

            await Page.Locator(".logout-button").ClickAsync();
            await Expect(Page).ToHaveURLAsync($"{baseUrl}/login");

            // Verify we cannot access dashboard after logout
            await Page.GotoAsync($"{baseUrl}/dashboard");
            await Expect(Page).ToHaveURLAsync($"{baseUrl}/login");
        }

        [Test]
        public async Task PasswordFieldShouldBeMasked()
        {
            await Expect(Page.Locator("#password")).ToHaveAttributeAsync("type", "password");
        }

        [Test]
        public async Task ForgotPasswordLinkWorks()
        {
            await Page.Locator("a[href*='forgot-password']").ClickAsync();
            await Expect(Page).ToHaveURLAsync(new Regex(".*forgot-password.*"));
        }

        [Test]
        public async Task SqlInjectionAttemptShouldFail()
        {
            await DoLogin("admin' OR '1'='1", "admin' OR '1'='1");

            await Expect(Page).ToHaveURLAsync($"{baseUrl}/login");
            await Expect(Page.Locator(".error-message")).ToBeVisibleAsync();
        }

        [Test]
        public async Task TestLoginWithSpacesInPassword()
        {
            await DoLogin(email, "Password 123!");
            await Expect(Page.Locator(".error-message")).ToBeVisibleAsync();
        }

        [Test]
        public async Task TestMultipleLoginAttempts()
        {
            for (int i = 0; i < 3; i++)
            {
                await DoLogin(email, $"wrongpass{i}");
                await Expect(Page.Locator(".error-message")).ToBeVisibleAsync();
                
                // Clear inputs for next attempt
                await Page.Locator("#email").ClearAsync();
                await Page.Locator("#password").ClearAsync();
            }

            await DoLogin(email, password);
            await Expect(Page).ToHaveURLAsync($"{baseUrl}/dashboard");
        }

        [Test]
        public async Task LoginWithEnterKey()
        {
            await Page.Locator("#email").FillAsync(email);
            await Page.Locator("#password").FillAsync(password);
            await Page.Locator("#password").PressAsync("Enter");

            await Expect(Page).ToHaveURLAsync(new Regex(".*dashboard.*"));
        }

        [Test]
        public async Task TestSessionTimeout()
        {
            await DoLogin(email, password);
            await Expect(Page).ToHaveURLAsync($"{baseUrl}/dashboard");

            // Assuming the server times out the session and redirects to login
            // Use ToPassAsync to wait for the backend to invalidate session and redirect,
            // avoiding hardcoded Task.Delay
            await Expect(async () =>
            {
                await Page.GotoAsync($"{baseUrl}/dashboard");
                await Expect(Page).ToHaveURLAsync($"{baseUrl}/login");
            }).ToPassAsync(new() { Timeout = 15000 });
        }

        [Test]
        public async Task LoginButtonShouldBeDisabledWhileLoading()
        {
            await Page.Locator("#email").FillAsync(email);
            await Page.Locator("#password").FillAsync(password);

            await Page.RouteAsync("**/login", async route => 
            {
                await Task.Delay(1000);
                await route.ContinueAsync();
            });

            var button = Page.Locator("button[type='submit']");
            
            _ = button.ClickAsync();
            await Expect(button).ToBeDisabledAsync();
        }
    }
}
